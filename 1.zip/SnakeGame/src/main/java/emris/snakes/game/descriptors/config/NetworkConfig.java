package emris.snakes.game.descriptors.config;

public interface NetworkConfig {

    int getPingDelayMs();

    int getNodeTimeoutMs();
}
