package emris.snakes.game.plane;

public interface Coordinates {

    int getX();

    int getY();
}
