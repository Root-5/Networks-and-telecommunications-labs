package emris.snakes.game.event;

@FunctionalInterface
public interface HandlerDescriptor {

    void remove();
}
