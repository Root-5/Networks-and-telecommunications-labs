package emris.snakes.gui.menu;

@FunctionalInterface
public interface RunningGamesView {

    void updateView();
}
